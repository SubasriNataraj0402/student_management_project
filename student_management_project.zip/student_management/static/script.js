function confirmDelete(studentName) {
    return window.confirm(`Are you sure you want to delete ${studentName}?`);
}
