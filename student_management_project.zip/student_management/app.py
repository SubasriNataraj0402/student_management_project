from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"

BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "students.db"


def get_db_connection():
    """Open a database connection and return rows as dictionaries."""
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database():
    """Create the students table when the application first starts."""
    with get_db_connection() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                department TEXT NOT NULL,
                marks REAL NOT NULL CHECK (marks >= 0 AND marks <= 100)
            )
        """)
        connection.commit()


@app.route("/")
def index():
    search = request.args.get("search", "").strip()
    with get_db_connection() as connection:
        if search:
            students = connection.execute(
                """SELECT * FROM students
                   WHERE name LIKE ? OR department LIKE ?
                   ORDER BY id DESC""",
                (f"%{search}%", f"%{search}%")
            ).fetchall()
        else:
            students = connection.execute(
                "SELECT * FROM students ORDER BY id DESC"
            ).fetchall()
    return render_template("index.html", students=students, search=search)


@app.route("/add", methods=["GET", "POST"])
def add_student():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        department = request.form.get("department", "").strip()
        marks_text = request.form.get("marks", "").strip()

        if not name or not email or not department or not marks_text:
            flash("Please fill in all fields.", "error")
            return render_template("add_student.html")

        try:
            marks = float(marks_text)
        except ValueError:
            flash("Marks must be a number.", "error")
            return render_template("add_student.html")

        if not 0 <= marks <= 100:
            flash("Marks must be between 0 and 100.", "error")
            return render_template("add_student.html")

        with get_db_connection() as connection:
            connection.execute(
                "INSERT INTO students (name, email, department, marks) VALUES (?, ?, ?, ?)",
                (name, email, department, marks)
            )
            connection.commit()

        flash("Student added successfully!", "success")
        return redirect(url_for("index"))

    return render_template("add_student.html")


@app.route("/edit/<int:student_id>", methods=["GET", "POST"])
def edit_student(student_id):
    with get_db_connection() as connection:
        student = connection.execute(
            "SELECT * FROM students WHERE id = ?", (student_id,)
        ).fetchone()

        if student is None:
            flash("Student not found.", "error")
            return redirect(url_for("index"))

        if request.method == "POST":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip()
            department = request.form.get("department", "").strip()
            marks_text = request.form.get("marks", "").strip()

            if not name or not email or not department or not marks_text:
                flash("Please fill in all fields.", "error")
                return render_template("edit_student.html", student=student)

            try:
                marks = float(marks_text)
            except ValueError:
                flash("Marks must be a number.", "error")
                return render_template("edit_student.html", student=student)

            if not 0 <= marks <= 100:
                flash("Marks must be between 0 and 100.", "error")
                return render_template("edit_student.html", student=student)

            connection.execute(
                """UPDATE students
                   SET name = ?, email = ?, department = ?, marks = ?
                   WHERE id = ?""",
                (name, email, department, marks, student_id)
            )
            connection.commit()

        if request.method == "POST":
            flash("Student updated successfully!", "success")
            return redirect(url_for("index"))

    return render_template("edit_student.html", student=student)


@app.route("/delete/<int:student_id>", methods=["POST"])
def delete_student(student_id):
    with get_db_connection() as connection:
        connection.execute("DELETE FROM students WHERE id = ?", (student_id,))
        connection.commit()
    flash("Student deleted.", "success")
    return redirect(url_for("index"))


if __name__ == "__main__":
    initialize_database()
    app.run(debug=True)
