# Student Management System

A beginner-friendly Full Stack Python project built with Flask, SQLite, HTML, CSS, and JavaScript.

## Features

- Add student records
- View all students
- Search by student name or department
- Edit student details
- Delete student records with a confirmation prompt
- Validate required fields and marks (0–100)
- Store records in a local SQLite database
- Responsive layout for desktop and mobile screens

## Requirements

- Python 3.9 or newer
- pip

## Run locally

### 1. Extract the ZIP file

Open a terminal inside the extracted `student_management` folder.

### 2. Create and activate a virtual environment (recommended)

Windows Command Prompt:

```bash
py -m venv .venv
.venv\Scripts\activate
```

Windows PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install -r requirements.txt
```

On Windows, `py -m pip install -r requirements.txt` also works.

### 4. Start the application

```bash
python app.py
```

On Windows you can also run `py app.py`.

### 5. Open the website

Visit http://127.0.0.1:5000 in your browser.

The `students.db` SQLite database is created automatically when the application starts.

## Upload to GitHub

1. Create a new empty repository on GitHub, for example `student-management-system`.
2. Extract this ZIP file.
3. Open a terminal inside the `student_management` folder.
4. Run:

```bash
git init
git add .
git commit -m "Initial student management system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-management-system.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username and use your actual repository URL. Do not upload passwords, API keys, virtual environments, or your local database.

## Project structure

```text
student_management/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── add_student.html
│   └── edit_student.html
└── static/
    ├── style.css
    └── script.js
```

## Learning notes

- Flask routes connect URLs to Python functions.
- Jinja templates display data in HTML.
- SQLite stores student records between app restarts.
- SQL placeholders (`?`) are used for values in database queries.
- This is a learning project. Before public production use, add proper authentication, CSRF protection, secure secret management, and deployment configuration.
